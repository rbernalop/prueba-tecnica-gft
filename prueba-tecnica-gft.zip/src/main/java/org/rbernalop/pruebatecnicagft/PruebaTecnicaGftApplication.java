package org.rbernalop.pruebatecnicagft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaTecnicaGftApplication {

  public static void main(String[] args) {
    SpringApplication.run(PruebaTecnicaGftApplication.class, args);
  }

}
